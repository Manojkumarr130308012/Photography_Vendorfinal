package com.shashank.platform.loginui.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.baoyachi.stepview.HorizontalStepView;
import com.baoyachi.stepview.bean.StepBean;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.PermissionListener;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.Length;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.shashank.platform.loginui.Api.Api;
import com.shashank.platform.loginui.R;
import com.shuhart.stepview.StepView;
import com.tiper.MaterialSpinner;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gun0912.tedimagepicker.builder.TedImagePicker;
import gun0912.tedimagepicker.builder.listener.OnMultiSelectedListener;

public class Register extends AppCompatActivity implements Validator.ValidationListener{
    private int currentStep = 0;
    LinearLayout lin1,lin2,lin3;
    List<String> locationname = new ArrayList<>();
    List<String> catgoryname = new ArrayList<>();
    List<String> servicename = new ArrayList<>();
    MaterialSpinner loc,category;
    String location="";
    String catg="";
    ChipGroup services;
    String imagestring="",imagestring1="",imagestring2="",Document_img1;
    ImageView IDProf, IDProf1, IDProf2;
    public  static final int RequestPermissionCode  = 1 ;
    String s = null;
    DatePickerDialog datepicker;
    @NotEmpty
    @Length(min = 3, max = 10)
    TextInputEditText dob;
    @NotEmpty
    @Length(min = 3, max = 50)
    TextInputEditText firstname;
    @NotEmpty
    @Length(min = 3, max = 50)
    TextInputEditText lastname;
    @NotEmpty
    @Length(min = 1, max = 50)
    TextInputEditText amount;
    @NotEmpty
    @Pattern(regex =  "^\\(?([0-9]{3})\\)?[-.\\s]?([0-9]{3})[-.\\s]?([0-9]{4})$")
    TextInputEditText mobile;
    @NotEmpty
    @Pattern(regex =  "^\\(?([0-9]{3})\\)?[-.\\s]?([0-9]{3})[-.\\s]?([0-9]{4})$")
    TextInputEditText watsapp;
    @NotEmpty
    @Email
    TextInputEditText email;
    @NotEmpty
    @Length(min = 3, max = 50)
    TextInputEditText companyname;
    @NotEmpty
    @Length(min = 3, max = 100)
    TextInputEditText address;
    @NotEmpty
    @Length(min = 3, max = 100)
    TextInputEditText description;
    @NotEmpty
    @Length(min = 3, max = 100)
    TextInputEditText password;
    private Validator validator;
    String dobstring,firstnamestring,lastnamestring,passwordstring,mobilestring,watsappstring,emailstring,amountstring,companynamestring,dobsting,addressstring,descriptionstring;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register);
        validator = new Validator(this);
        validator.setValidationListener(this);

        lin1=findViewById(R.id.lin1);
        lin2=findViewById(R.id.lin2);
        lin3=findViewById(R.id.lin3);
        IDProf1 = (ImageView) findViewById(R.id.IdProf1);
        IDProf2 = (ImageView) findViewById(R.id.IdProf2);
        password = findViewById(R.id.password);



        loc=findViewById(R.id.location);
        category=findViewById(R.id.category);
        services=findViewById(R.id.chipGroup);
        dob=findViewById(R.id.dob);




        firstname=findViewById(R.id.firstname);
        lastname=findViewById(R.id.lastname);
        mobile=findViewById(R.id.mobile);
        watsapp=findViewById(R.id.watsapp);
        email=findViewById(R.id.email);
        companyname=findViewById(R.id.companyname);
        address=findViewById(R.id.address);
        description=findViewById(R.id.description);
        amount=findViewById(R.id.amount);









        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                datepicker = new DatePickerDialog(Register.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                dob.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                datepicker.show();
            }
        });





        getitem();
        getservice();
        getcatgory();
        loc.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {

            @Override
            public void onNothingSelected(MaterialSpinner materialSpinner) {

            }

            @Override
            public void onItemSelected(MaterialSpinner materialSpinner, View view, int i, long l) {
                if (i > -1) {
                    location = locationname.get(i).toString();
                } else {
                    location = "";
                }
            }
        });
        category.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {

            @Override
            public void onNothingSelected(MaterialSpinner materialSpinner) {

            }

            @Override
            public void onItemSelected(MaterialSpinner materialSpinner, View view, int i, long l) {
                if (i > -1) {
                    catg = catgoryname.get(i).toString();
                } else {
                    catg = "";
                }
            }
        });

        if (currentStep == 0){
            lin2.setVisibility(View.GONE);
            lin3.setVisibility(View.GONE);
        }

        final StepView stepView = findViewById(R.id.step_view);
        stepView.setOnStepClickListener(new StepView.OnStepClickListener() {
            @Override
            public void onStepClick(int step) {
                Toast.makeText(Register.this, "Step " + step, Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(Register.this, ""+currentStep, Toast.LENGTH_SHORT).show();

                if (currentStep == 0){
                    firstnamestring=firstname.getText().toString();
                    lastnamestring=lastname.getText().toString();
                    mobilestring=mobile.getText().toString();
                    watsappstring=watsapp.getText().toString();
                    emailstring=email.getText().toString();


                    if (!firstnamestring.equals("")&!lastnamestring.equals("")&!mobilestring.equals("")&!watsappstring.equals("")&!emailstring.equals(""))
                    {
                        validator.validate();
                        lin1.setVisibility(View.GONE);
                        lin2.setVisibility(View.VISIBLE);
                        lin3.setVisibility(View.GONE);

                        if (currentStep < stepView.getStepCount() - 1) {
                            currentStep++;
                            stepView.go(currentStep, true);

                        } else {
                            stepView.done(true);
                        }
                    }else{
                        validator.validate();
                    }


                }else  if (currentStep == 1){

                    companynamestring=companyname.getText().toString();
                    amountstring=amount.getText().toString();
                    dobstring=dob.getText().toString();
                    addressstring=address.getText().toString();
                    descriptionstring=description.getText().toString();


                    if (!companynamestring.equals("")&!amountstring.equals("")&!dobstring.equals("")&!addressstring.equals("")&!descriptionstring.equals(""))
                    {
                        validator.validate();
                        lin1.setVisibility(View.GONE);
                        lin2.setVisibility(View.GONE);
                        lin3.setVisibility(View.VISIBLE);
                        showSelections();
                        if (currentStep < stepView.getStepCount() - 1) {
                            currentStep++;
                            stepView.go(currentStep, true);

                        } else {
                            stepView.done(true);
                        }
                    }else{
                        validator.validate();
                    }


                }else  if (currentStep == 2){
                    passwordstring=password.getText().toString();
                    if (imagestring1.equals("")&imagestring2.equals("")&location.equals(""))
                    {

                        validator.validate();
                        if (imagestring1 == ""){
                            Toast.makeText(Register.this, "Please Select the Profile", Toast.LENGTH_SHORT).show();
                        }
                        if (imagestring2 == ""){
                            Toast.makeText(Register.this, "Please Select the Prof", Toast.LENGTH_SHORT).show();
                        }
//                        if (s.equals(null)){
//                            Toast.makeText(Register.this, "Please Select the Catgory", Toast.LENGTH_SHORT).show();
//                        }
                        if (location.equals("")){
                            Toast.makeText(Register.this, "Please Select the Location", Toast.LENGTH_SHORT).show();
                        }

                    }else{
                        validator.validate();
                        lin1.setVisibility(View.GONE);
                        lin2.setVisibility(View.GONE);
                        lin3.setVisibility(View.VISIBLE);
                        showSelections();
                        if (currentStep < stepView.getStepCount() - 1) {
                            currentStep++;
                            stepView.go(currentStep, true);


                        } else {
                            stepView.done(true);

                        }
                        RegisterData();
                        SendDetail();
                    }




                }

            }
        });
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Register.this, ""+currentStep, Toast.LENGTH_SHORT).show();

                if (currentStep == 0){
                    lin1.setVisibility(View.VISIBLE);
                    lin2.setVisibility(View.GONE);
                    lin3.setVisibility(View.GONE);
                    if (currentStep > 0) {
                        currentStep--;
                    }
                    stepView.done(false);
                    stepView.go(currentStep, true);
                }else  if (currentStep == 1){
                    lin1.setVisibility(View.VISIBLE);
                    lin2.setVisibility(View.GONE);
                    lin3.setVisibility(View.GONE);
                    if (currentStep > 0) {
                        currentStep--;
                    }
                    stepView.done(false);
                    stepView.go(currentStep, true);
                }else  if (currentStep == 2){
                    lin1.setVisibility(View.GONE);
                    lin2.setVisibility(View.VISIBLE);
                    lin3.setVisibility(View.GONE);
                    if (currentStep > 0) {
                        currentStep--;
                    }
                    stepView.done(false);
                    stepView.go(currentStep, true);
                }


            }
        });
        List<String> steps = new ArrayList<>();
        steps.add("Basic Details");
        steps.add("Business Details");
        steps.add("Documents");
        steps.set(steps.size() - 1, steps.get(steps.size() - 1));
        stepView.setSteps(steps);
        IDProf1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();

            }
        });
        IDProf2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Dexter.withContext(getApplicationContext())
                        .withPermission(Manifest.permission.CAMERA)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                startActivityForResult( intent,2);
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(com.karumi.dexter.listener.PermissionRequest permissionRequest, PermissionToken permissionToken) {

                            }


                        }).check();

            }
        });
    }







    private void selectImage() {
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };
      AlertDialog.Builder builder = new builder(Register.this,R.style.AppTheme);
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f = new File(Environment.getExternalStorageDirectory(), "temp.jpg");
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                    startActivityForResult(intent, 1);
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Intent intent = new   Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 2);
                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                File f = new File(Environment.getExternalStorageDirectory().toString());
                for (File temp : f.listFiles()) {
                    if (temp.getName().equals("temp.jpg")) {
                        f = temp;
                        break;
                    }
                }
                try {
                    Bitmap bitmap;
                    BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
                    bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(), bitmapOptions);
                    bitmap=getResizedBitmap(bitmap, 400);
                    IDProf.setImageBitmap(bitmap);
                    BitMapToString(bitmap);
                    String path = android.os.Environment
                            .getExternalStorageDirectory()
                            + File.separator
                            + "Phoenix" + File.separator + "default";
                    f.delete();
                    OutputStream outFile = null;
                    File file = new File(path, String.valueOf(System.currentTimeMillis()) + ".jpg");
                    try {
                        outFile = new FileOutputStream(file);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outFile);
                        outFile.flush();
                        outFile.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (requestCode == 2) {
                Uri selectedImage = data.getData();
                String[] filePath = { MediaStore.Images.Media.DATA };
                Cursor c = getContentResolver().query(selectedImage,filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                c.close();
                Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                thumbnail=getResizedBitmap(thumbnail, 400);
                Log.w(".......", picturePath+"");
                IDProf.setImageBitmap(thumbnail);
                BitMapToString(thumbnail);
            }
        }
    }
    public String BitMapToString(Bitmap userImage1) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        userImage1.compress(Bitmap.CompressFormat.PNG, 60, baos);
        byte[] b = baos.toByteArray();
        Document_img1 = Base64.encodeToString(b, Base64.DEFAULT);
        return Document_img1;
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    private void SendDetail() {
        final ProgressDialog loading = new ProgressDialog(Register.this);
        loading.setMessage("Please Wait...");
        loading.show();
        loading.setCanceledOnTouchOutside(false);
        RetryPolicy mRetryPolicy = new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.registerurl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            Log.d("JSON", response);

                            JSONObject eventObject = new JSONObject(response);
                            String error_status = eventObject.getString("error");
                            if (error_status.equals("true")) {
                                String error_msg = eventObject.getString("msg");
                                ContextThemeWrapper ctw = new ContextThemeWrapper( Register.this,R.style.AppTheme);
                                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ctw);
                                alertDialogBuilder.setTitle("Vendor Detail");
                                alertDialogBuilder.setCancelable(false);
                                alertDialogBuilder.setMessage(error_msg);
                                alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                    }
                                });
                                alertDialogBuilder.show();

                            } else {
                                String error_msg = eventObject.getString("msg");
                                ContextThemeWrapper ctw = new ContextThemeWrapper( Register.this, R.style.Theme_AlertDialog);
                                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ctw);
                                alertDialogBuilder.setTitle("Registration");
                                alertDialogBuilder.setCancelable(false);
                                alertDialogBuilder.setMessage(error_msg);
//                                alertDialogBuilder.setIcon(R.drawable.doubletick);
                                alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        Intent intent=new Intent(Register.this,Register.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                alertDialogBuilder.show();
                            }
                        }catch(Exception e){
                            Log.d("Tag", e.getMessage());

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                            ContextThemeWrapper ctw = new ContextThemeWrapper( Register.this, R.style.Theme_AlertDialog);
                            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ctw);
                            alertDialogBuilder.setTitle("No connection");
                            alertDialogBuilder.setMessage(" Connection time out error please try again ");
                            alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                            alertDialogBuilder.show();
                        } else if (error instanceof AuthFailureError) {
                            ContextThemeWrapper ctw = new ContextThemeWrapper( Register.this, R.style.Theme_AlertDialog);
                            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ctw);
                            alertDialogBuilder.setTitle("Connection Error");
                            alertDialogBuilder.setMessage(" Authentication failure connection error please try again ");
                            alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                            alertDialogBuilder.show();
                            //TODO
                        } else if (error instanceof ServerError) {
                            ContextThemeWrapper ctw = new ContextThemeWrapper( Register.this, R.style.Theme_AlertDialog);
                            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ctw);
                            alertDialogBuilder.setTitle("Connection Error");
                            alertDialogBuilder.setMessage("Connection error please try again");
                            alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                            alertDialogBuilder.show();
                            //TODO
                        } else if (error instanceof NetworkError) {
                            ContextThemeWrapper ctw = new ContextThemeWrapper( Register.this, R.style.Theme_AlertDialog);
                            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ctw);
                            alertDialogBuilder.setTitle("Connection Error");
                            alertDialogBuilder.setMessage("Network connection error please try again");
                            alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                            alertDialogBuilder.show();
                            //TODO
                        } else if (error instanceof ParseError) {
                            ContextThemeWrapper ctw = new ContextThemeWrapper( Register.this, R.style.Theme_AlertDialog);
                            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ctw);
                            alertDialogBuilder.setTitle("Error");
                            alertDialogBuilder.setMessage("Parse error");
                            alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                            alertDialogBuilder.show();
                        }
//                        Toast.makeText(Login_Activity.this,error.toString(), Toast.LENGTH_LONG ).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<String,String>();
                map.put(KEY_User_Document1,Document_img1);
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        stringRequest.setRetryPolicy(mRetryPolicy);
        requestQueue.add(stringRequest);
    }




    public void getitem() {



        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JSONObject object = new JSONObject();


        String url = Api.locationurl;

        // Enter the correct url for your api service site

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
//                            message = (String) response.get("status");
                            Log.e("xdddddddddddd", "" + response);

                            JSONArray jObject1 = response.getJSONArray("location");

                            for (int i = 0; i < jObject1.length(); i++) {
                                JSONObject jsonObject = jObject1.getJSONObject(i);
                                locationname.add(jsonObject.getString("location_name"));
                            }
                            Log.e("locationname", "" + locationname.toString());
                            ArrayAdapter<String> _Adapter = new ArrayAdapter<String>(Register.this, android.R.layout.simple_spinner_item, locationname);
                            _Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            loc.setAdapter(_Adapter);
//                    mTxtExpense.setText(objResDetails.getTodayPayments()+" Rs");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("xddddd", "" + error);

            }
        });
        requestQueue.add(jsonObjectRequest);


    }



    public void getcatgory() {



        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JSONObject object = new JSONObject();


        String url = Api.catgorurl;

        // Enter the correct url for your api service site

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
//                            message = (String) response.get("status");
                            Log.e("xdddddddddddd", "" + response);

                            JSONArray jObject1 = response.getJSONArray("category");

                            for (int i = 0; i < jObject1.length(); i++) {
                                JSONObject jsonObject = jObject1.getJSONObject(i);
                                catgoryname.add(jsonObject.getString("category_name"));
                            }
                            Log.e("catgoryname", "" + catgoryname.toString());
                            ArrayAdapter<String> _Adapter = new ArrayAdapter<String>(Register.this, android.R.layout.simple_spinner_item, catgoryname);
                            _Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            category.setAdapter(_Adapter);
//                    mTxtExpense.setText(objResDetails.getTodayPayments()+" Rs");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("xddddd", "" + error);

            }
        });
        requestQueue.add(jsonObjectRequest);


    }
    public void getservice() {



        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JSONObject object = new JSONObject();


        String url = Api.serviceurl;

        // Enter the correct url for your api service site

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
//                            message = (String) response.get("status");
                            Log.e("xdddddddddddd", "" + response);

                            JSONArray jObject1 = response.getJSONArray("services");

                            for (int i = 0; i < jObject1.length(); i++) {
                                JSONObject jsonObject = jObject1.getJSONObject(i);
                                servicename.add(jsonObject.getString("services_name"));



                                try {
                                    LayoutInflater inflater = LayoutInflater.from(Register.this);

                                    // Create a Chip from Layout.
                                    Chip newChip = (Chip) inflater.inflate(R.layout.layout_chip_entry, services, false);
                                    newChip.setText(jsonObject.getString("services_name"));

                                    //
                                    // Other methods:
                                    //
                                    // newChip.setCloseIconVisible(true);
                                    // newChip.setCloseIconResource(R.drawable.your_icon);
                                    // newChip.setChipIconResource(R.drawable.your_icon);
                                    // newChip.setChipBackgroundColorResource(R.color.red);
                                    // newChip.setTextAppearanceResource(R.style.ChipTextStyle);
                                    // newChip.setElevation(15);

                                    services.addView(newChip);

                                    // Set Listener for the Chip:
                                    newChip.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                            handleChipCheckChanged((Chip) buttonView, isChecked);
                                        }
                                    });

                                    newChip.setOnCloseIconClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            handleChipCloseIconClicked((Chip) v);
                                        }
                                    });


//                                    this.editTextKeyword.setText("");

                                } catch (Exception e) {
                                    e.printStackTrace();
//                                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                            Log.e("category_name", "" + catgoryname.toString());

//                    mTxtExpense.setText(objResDetails.getTodayPayments()+" Rs");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("xddddd", "" + error);

            }
        });
        requestQueue.add(jsonObjectRequest);


    }

    private void showSelections()  {
        int count = services.getChildCount();


        for(int i=0;i< count; i++) {
            Chip child = (Chip) services.getChildAt(i);

            if(!child.isChecked()) {
                continue;
            }

            if(s == null)  {
                s = child.getText().toString();
            } else {
                s += ", " + child.getText().toString();
            }
        }
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // User close a Chip.
    private void handleChipCloseIconClicked(Chip chip) {
        ChipGroup parent = (ChipGroup) chip.getParent();
        parent.removeView(chip);
    }

    // Chip Checked Changed
    private void handleChipCheckChanged(Chip chip, boolean isChecked) {
    }

    @Override
    public void onValidationSucceeded() {
        Toast.makeText(this, "We got it right!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(this);
            // Display error messages
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        }
    }


    private void RegisterData() {

        Toast.makeText(this, "Loading", Toast.LENGTH_SHORT).show();
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JSONObject object = new JSONObject();
        try {
//            SimpleDateFormat currentDate = new SimpleDateFormat("dd/MM/yyyy");
//            Date todayDate = new Date();
//            String thisDate = currentDate.format(todayDate);
            object.put("fname",""+firstnamestring);
            object.put("lname",""+lastnamestring);
            object.put("mobile",""+mobilestring);
            object.put("whatsapp   ",""+watsappstring);
            object.put("email",""+emailstring);
            object.put("cname",""+companynamestring);
            object.put("amount",""+amountstring);
            object.put("dob",""+dobsting);
            object.put("address",""+addressstring);
            object.put("desc",""+descriptionstring);
            object.put("location",""+location);
            object.put("category",""+catg);
            object.put("service",""+s);
            object.put("image   ",""+imagestring1);
            object.put("proof",""+imagestring2);
            object.put("password",""+passwordstring);



        } catch (JSONException e) {
            e.printStackTrace();
        }


        String url =Api.registerurl;

        // Enter the correct url for your api service site

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,url,object,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Toast.makeText(Register.this, "Sucessfully Registered", Toast.LENGTH_SHORT).show();
                        Intent i=new Intent(Register.this,Plans.class);
                        startActivity(i);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("xddddd",""+error);

            }
        });
        requestQueue.add(jsonObjectRequest);
    }
}