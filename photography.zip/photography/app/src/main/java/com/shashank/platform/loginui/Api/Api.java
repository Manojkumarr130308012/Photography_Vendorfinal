package com.shashank.platform.loginui.Api;

public class Api {

    public static final String Mainurl="https://demo.njcreators.in/hc/api/";

    public static final String locationurl=Mainurl+"location";

    public static final String Loginurl=Mainurl+"vendor_login";

    public static final String catgorurl=Mainurl+"category";


    public static final String serviceurl=Mainurl+"services";


    public static final String registerurl=Mainurl+"vendor_singup";

}
