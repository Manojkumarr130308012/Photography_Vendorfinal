package com.shashank.platform.loginui.font;

import android.gesture.Gesture;
import android.gesture.GestureOverlayView;

public class SignGestureListener implements GestureOverlayView.OnGesturePerformedListener {


    @Override
    public void onGesturePerformed(GestureOverlayView gestureOverlayView, Gesture gesture) {

    }
}